const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt');
const app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static('public'));


app.use(session({
  secret: '123',
  resave: true,
  saveUninitialized: true
}));

const pool = mysql.createPool({
  connectionLimit: 10,
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'tm'
});

function queryDatabase(query, values, callback) {
  pool.getConnection((err, connection) => {
    if (err) return callback(err);

    connection.query(query, values, (error, results) => {
      connection.release();
      callback(error, results);
    });
  });
}

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/login.html');
});


app.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !email.endsWith('@gmail.com')) {
    return res.redirect('/?error=email');
  }

  if (!password || password.length < 8) {
    return res.redirect('/?error=password_length');
  }

  const digitCount = (password.match(/\d/g) || []).length;
  if (digitCount < 3) {
    return res.redirect('/?error=password_digits');
  }

  const sql = 'SELECT * FROM useraccount WHERE email = ?';
  queryDatabase(sql, [email], (err, results) => {
    if (err) throw err;

    if (results.length === 0) {
      return res.redirect('/?error=user');
    }

    const user = results[0];
    if (!user.password || typeof user.password !== 'string' || !user.password.startsWith('$2')) {
      return res.redirect('/?error=invalid_db_password');
    }

    bcrypt.compare(password.trim(), user.password.trim(), (err, result) => {
      if (err) {
        return res.redirect('/?error=bcrypt');
      }
      if (!result) {
        return res.redirect('/?error=password');
      }
      req.session.user = user;
      switch (user.role) {
        case 'student':
          res.redirect('/student.html');
          break;
        case 'instructor':
          res.redirect('/instructor.html');
          break;
        case 'dean':
          res.redirect('/dean.html');
          break;
        default:
          res.redirect('/');
      }
    });
  });
});

function ensureAuthenticated(req, res, next) {
  if (req.session.user) return next();
  res.redirect('/');
}

app.get('/student.html', ensureAuthenticated, (req, res) => {
  res.sendFile(__dirname + '/public/studentdash.html');
});

app.get('/instructor.html', ensureAuthenticated, (req, res) => {
  res.sendFile(__dirname + '/public/instructordash.html');
});

app.get('/dean.html', ensureAuthenticated, (req, res) => {
  res.sendFile(__dirname + '/public/deandash.html');
});

app.get('/logout', (req, res) => {
  req.session.destroy(() => {
    res.redirect('/');
  });
});


app.get('/api/users', (req, res) => {
  // Get all users from useraccount
  const sql = 'SELECT * FROM useraccount';
  queryDatabase(sql, [], (err, users) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (!users.length) return res.json([]);

    // Fetch all names from student, instructor, and dean tables in parallel
    const queries = [
      new Promise((resolve, reject) => {
        pool.query('SELECT UserID, Name FROM student', (err, results) => {
          if (err) return resolve([]); // Don't reject, just return empty
          resolve(results);
        });
      }),
      new Promise((resolve, reject) => {
        pool.query('SELECT UserID, Name FROM instructor', (err, results) => {
          if (err) return resolve([]);
          resolve(results);
        });
      }),
      new Promise((resolve, reject) => {
        pool.query('SELECT UserID, Name FROM dean', (err, results) => {
          if (err) return resolve([]);
          resolve(results);
        });
      })
    ];

    Promise.all(queries).then(([students, instructors, deans]) => {
      // Build lookup maps
      const studentMap = Object.fromEntries(students.map(s => [s.UserID, s.Name]));
      const instructorMap = Object.fromEntries(instructors.map(i => [i.UserID, i.Name]));
      const deanMap = Object.fromEntries(deans.map(d => [d.UserID, d.Name]));

      // Attach the correct name to each user
      const result = users.map(user => {
        let name = user.Name || '';
        if (!name) {
          if (user.role === 'student') name = studentMap[user.UserID] || '';
          else if (user.role === 'instructor') name = instructorMap[user.UserID] || '';
          else if (user.role === 'dean') name = deanMap[user.UserID] || '';
        }
        return { ...user, name };
      });
      res.json(result);
    });
  });
});

app.get('/api/users/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'SELECT * FROM useraccount WHERE UserID = ?';
  queryDatabase(sql, [id], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (results.length === 0) return res.status(404).json({ error: 'User not found' });
    res.json(results[0]);
  });
});

app.post('/api/users', async (req, res) => {
    const { name, email, password, role } = req.body;
    const hashedPassword = await bcrypt.hash(password, 10);
    const sql = 'INSERT INTO useraccount (name, email, password, role) VALUES (?, ?, ?, ?)';
    queryDatabase(sql, [name, email, hashedPassword, role], (err, results) => {
        if (err) throw err;
        // If role is instructor, also add to instructor table with default values
        if (role === 'instructor') {
            const userId = results.insertId;
            const instructorSql = 'INSERT INTO instructor (UserID, Name, Department, OfficeLocation) VALUES (?, ?, ?, ?)';
            queryDatabase(instructorSql, [userId, name, '-', '-'], (err2) => {
                if (err2) return res.status(500).json({ error: 'Database error (instructor sync)', details: err2.message });
                res.json({ success: true, id: userId, refreshInstructors: true });
            });
        } else {
            res.json({ success: true, id: results.insertId });
        }
    });
});

app.put('/api/users/:id', async (req, res) => {
    const { name, email, password, role } = req.body;
    const { id } = req.params;
    let sql, params;
    if (password) {
        const hashedPassword = await bcrypt.hash(password, 10);
        sql = 'UPDATE useraccount SET name = ?, email = ?, password = ?, role = ? WHERE UserID = ?';
        params = [name, email, hashedPassword, role, id];
    } else {
        sql = 'UPDATE useraccount SET name = ?, email = ?, role = ? WHERE UserID = ?';
        params = [name, email, role, id];
    }
    queryDatabase(sql, params, (err, results) => {
        if (err) throw err;
        res.json({ success: true });
    });
});

app.delete('/api/users/:id', (req, res) => {
  const userId = req.params.id;
  // First, get the user to check role
  queryDatabase('SELECT role FROM useraccount WHERE UserID = ?', [userId], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error (find user)', details: err.message });
    if (!results.length) return res.status(404).json({ error: 'User not found' });
    const role = results[0].role;
    // Delete from useraccount
    queryDatabase('DELETE FROM useraccount WHERE UserID = ?', [userId], (err) => {
      if (err) return res.status(500).json({ error: 'Database error (delete useraccount)', details: err.message });
      // If instructor, delete from instructor table as well
      if (role === 'instructor') {
        queryDatabase('DELETE FROM instructor WHERE UserID = ?', [userId], (err) => {
          if (err) return res.status(500).json({ error: 'Database error (delete instructor)', details: err.message });
          res.json({ success: true, refreshInstructors: true });
        });
      } else {
        res.json({ success: true });
      }
    });
  });
});

// Schedule API endpoints
app.get('/api/schedules', (req, res) => {
  const sql = 'SELECT * FROM schedules ORDER BY day, startTime';
  queryDatabase(sql, [], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(results);
  });
});

app.get('/api/schedules/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'SELECT * FROM schedules WHERE scheduleId = ?';
  queryDatabase(sql, [id], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (results.length === 0) return res.status(404).json({ error: 'Schedule not found' });
    res.json(results[0]);
  });
});

app.post('/api/schedules', (req, res) => {
  const { subject, instructor, day, startTime, endTime, room } = req.body;
  const sql = 'INSERT INTO schedules (subject, instructor, day, startTime, endTime, room) VALUES (?, ?, ?, ?, ?, ?)';
  queryDatabase(sql, [subject, instructor, day, startTime, endTime, room], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json({ success: true, id: results.insertId });
  });
});

app.put('/api/schedules/:id', (req, res) => {
  const { subject, instructor, day, startTime, endTime, room } = req.body;
  const { id } = req.params;
  const sql = 'UPDATE schedules SET subject = ?, instructor = ?, day = ?, startTime = ?, endTime = ?, room = ? WHERE scheduleId = ?';
  queryDatabase(sql, [subject, instructor, day, startTime, endTime, room, id], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json({ success: true });
  });
});

app.delete('/api/schedules/:id', (req, res) => {
  const scheduleId = req.params.id;
  const sql = 'DELETE FROM schedules WHERE scheduleId = ?';
  queryDatabase(sql, [scheduleId], (err, result) => {
    if (err) return res.status(500).json({ success: false, error: err.message });
    res.json({ success: true });
  });
});

// Subjects
app.get('/api/subject', (req, res) => {
  queryDatabase('SELECT * FROM subject', [], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(results);
  });
});

// Instructors
app.get('/api/instructors', (req, res) => {
  queryDatabase('SELECT InstructorID as instructor_id, UserID as user_id, Name as name, Department as department, OfficeLocation as office_location FROM instructor', [], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(results);
  });
});

// Add Instructor
app.post('/api/instructors', async (req, res) => {
  const { name, department, office_location } = req.body;
  const password = 'wlccicte123';
  const role = 'instructor';
  const hashedPassword = await bcrypt.hash(password, 10);

  // Find the next available unique email
  const emailPrefix = 'instructor';
  const emailDomain = '@gmail.com';
  const emailQuery = `SELECT email FROM useraccount WHERE email LIKE '${emailPrefix}%${emailDomain}'`;
  queryDatabase(emailQuery, [], (err, results) => {
    if (err) {
      console.error('Error checking existing emails:', err);
      return res.status(500).json({ error: 'Database error (email check)', details: err.message });
    }
    let maxN = 0;
    results.forEach(row => {
      const match = row.email.match(/^instructor(\d*)@gmail.com$/);
      if (match) {
        const n = parseInt(match[1] || '0', 10);
        if (n > maxN) maxN = n;
      }
    });
    const nextN = maxN + 1;
    const email = `${emailPrefix}${nextN}${emailDomain}`;

    // Insert into useraccount first
    const userSql = 'INSERT INTO useraccount (name, email, password, role) VALUES (?, ?, ?, ?)';
    queryDatabase(userSql, [name, email, hashedPassword, role], (err, userResult) => {
      if (err) {
        console.error('Error inserting into useraccount:', err);
        return res.status(500).json({ error: 'Database error (useraccount)', details: err.message });
      }
      const userId = userResult.insertId;
      // Insert into instructor table (no Email column)
      const instructorSql = 'INSERT INTO instructor (UserID, Name, Department, OfficeLocation) VALUES (?, ?, ?, ?)';
      queryDatabase(instructorSql, [userId, name, department, office_location], (err, instructorResult) => {
        if (err) {
          console.error('Error inserting into instructor:', err);
          return res.status(500).json({ error: 'Database error (instructor)', details: err.message });
        }
        res.json({ success: true, id: instructorResult.insertId, email });
      });
    });
  });
});

// Get a single instructor by ID
app.get('/api/instructors/:id', (req, res) => {
  const { id } = req.params;
  queryDatabase('SELECT InstructorID as instructor_id, UserID as user_id, Name as name, Department as department, OfficeLocation as office_location FROM instructor WHERE InstructorID = ?', [id], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    if (results.length === 0) return res.status(404).json({ error: 'Instructor not found' });
    res.json(results[0]);
  });
});

// Edit Instructor (no email sync)
app.put('/api/instructors/:id', (req, res) => {
  const { id } = req.params;
  const { name, department, office_location } = req.body;
  // First, get the instructor to find the UserID
  queryDatabase('SELECT UserID FROM instructor WHERE InstructorID = ?', [id], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error (find instructor)', details: err.message });
    if (!results.length) return res.status(404).json({ error: 'Instructor not found' });
    const userId = results[0].UserID;
    // Update instructor table (no Email column)
    queryDatabase('UPDATE instructor SET Name = ?, Department = ?, OfficeLocation = ? WHERE InstructorID = ?', [name, department, office_location, id], (err) => {
      if (err) return res.status(500).json({ error: 'Database error (update instructor)', details: err.message });
      // Update useraccount table (name only)
      queryDatabase('UPDATE useraccount SET name = ? WHERE UserID = ?', [name, userId], (err) => {
        if (err) return res.status(500).json({ error: 'Database error (update useraccount)', details: err.message });
        res.json({ success: true });
      });
    });
  });
});

// Edit User (sync instructor if role is instructor, including email)
app.put('/api/users/:id', async (req, res) => {
  const { name, email, password, role } = req.body;
  const { id } = req.params;
  let sql, params;
  if (password) {
    const hashedPassword = await bcrypt.hash(password, 10);
    sql = 'UPDATE useraccount SET name = ?, email = ?, password = ?, role = ? WHERE UserID = ?';
    params = [name, email, hashedPassword, role, id];
  } else {
    sql = 'UPDATE useraccount SET name = ?, email = ?, role = ? WHERE UserID = ?';
    params = [name, email, role, id];
  }
  queryDatabase(sql, params, (err, results) => {
    if (err) throw err;
    // If role is instructor, update instructor table as well (including email)
    if (role === 'instructor') {
      queryDatabase('UPDATE instructor SET Name = ?, Email = ? WHERE UserID = ?', [name, email, id], (err) => {
        if (err) return res.status(500).json({ error: 'Database error (update instructor)', details: err.message });
        res.json({ success: true });
      });
    } else {
      res.json({ success: true });
    }
  });
});

// Delete Instructor
app.delete('/api/instructors/:id', (req, res) => {
  const { id } = req.params;
  // First, get the instructor to find the UserID
  queryDatabase('SELECT UserID FROM instructor WHERE InstructorID = ?', [id], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error (find instructor)', details: err.message });
    if (!results.length) return res.status(404).json({ error: 'Instructor not found' });
    const userId = results[0].UserID;
    // Delete from instructor table
    queryDatabase('DELETE FROM instructor WHERE InstructorID = ?', [id], (err) => {
      if (err) return res.status(500).json({ error: 'Database error (delete instructor)', details: err.message });
      // Delete from useraccount table
      queryDatabase('DELETE FROM useraccount WHERE UserID = ?', [userId], (err) => {
        if (err) return res.status(500).json({ error: 'Database error (delete useraccount)', details: err.message });
        res.json({ success: true });
      });
    });
  });
});

// Rooms (should actually be classrooms)
app.get('/api/classroom', (req, res) => {
  queryDatabase('SELECT * FROM classroom', [], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(results);
  });
});

// Courses
app.get('/api/courses', (req, res) => {
  queryDatabase('SELECT CourseCode as course_code, CourseName as course_name FROM course', [], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error' });
    res.json(results);
  });
});

// Add Course
app.post('/api/courses', (req, res) => {
  const { course_code, course_name } = req.body;
  const sql = 'INSERT INTO course (CourseCode, CourseName) VALUES (?, ?)';
  queryDatabase(sql, [course_code, course_name], (err, result) => {
    if (err) return res.status(500).json({ error: 'Database error (add course)', details: err.message });
    res.json({ success: true });
  });
});
// Edit Course
app.put('/api/courses/:code', (req, res) => {
  const { code } = req.params;
  const { course_name } = req.body;
  const sql = 'UPDATE course SET CourseName = ? WHERE CourseCode = ?';
  queryDatabase(sql, [course_name, code], (err, result) => {
    if (err) return res.status(500).json({ error: 'Database error (edit course)', details: err.message });
    res.json({ success: true });
  });
});
// Delete Course
app.delete('/api/courses/:code', (req, res) => {
  const { code } = req.params;
  const sql = 'DELETE FROM course WHERE CourseCode = ?';
  queryDatabase(sql, [code], (err, result) => {
    if (err) return res.status(500).json({ error: 'Database error (delete course)', details: err.message });
    res.json({ success: true });
  });
});

// Sections
app.get('/api/sections', (req, res) => {
  const sql = `SELECT s.SectionID as section_id, s.SectionNumber as section_name, s.CourseCode as course_code, c.CourseName as course_name
               FROM section s
               LEFT JOIN course c ON s.CourseCode = c.CourseCode`;
  queryDatabase(sql, [], (err, results) => {
    if (err) return res.status(500).json({ error: 'Database error (fetch sections)', details: err.message });
    res.json(results);
  });
});

app.post('/api/sections', (req, res) => {
  const { section_name, course_code, instructor_id, classroom_id, slot_id } = req.body;
  const sql = 'INSERT INTO section (SectionNumber, CourseCode, InstructorID, ClassroomID, SlotID) VALUES (?, ?, ?, ?, ?)';
  queryDatabase(sql, [section_name, course_code, instructor_id || null, classroom_id || null, slot_id || null], (err, result) => {
    if (err) return res.status(500).json({ success: false, error: 'Database error', details: err.message });
    res.json({ success: true });
  });
});

app.put('/api/sections/:id', (req, res) => {
  const { id } = req.params;
  const { section_name, course_code, instructor_id, classroom_id, slot_id } = req.body;
  const sql = 'UPDATE section SET SectionNumber = ?, CourseCode = ?, InstructorID = ?, ClassroomID = ?, SlotID = ? WHERE SectionID = ?';
  queryDatabase(sql, [section_name, course_code, instructor_id || null, classroom_id || null, slot_id || null, id], (err, result) => {
    if (err) return res.status(500).json({ success: false, error: 'Database error', details: err.message });
    res.json({ success: true });
  });
});

app.delete('/api/sections/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM section WHERE SectionID = ?';
  queryDatabase(sql, [id], (err, result) => {
    if (err) return res.status(500).json({ error: 'Database error (delete section)', details: err.message });
    res.json({ success: true });
  });
});

app.listen(3000, () => {
  console.log('Server running at http://localhost:3000');
});